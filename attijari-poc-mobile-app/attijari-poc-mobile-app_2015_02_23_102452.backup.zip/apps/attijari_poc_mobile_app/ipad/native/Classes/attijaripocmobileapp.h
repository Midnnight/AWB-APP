//
//  MyAppDelegate.h
//
//

#import "WLAppDelegate.h"
#import "WL.h"

@interface MyAppDelegate : WLAppDelegate <WLInitWebFrameworkDelegate> {
    
}

@end


/* JavaScript content from js/pages/menus/top-menu.js in folder common */


/* JavaScript content from js/pages/next-best-offer-view.js in folder common */

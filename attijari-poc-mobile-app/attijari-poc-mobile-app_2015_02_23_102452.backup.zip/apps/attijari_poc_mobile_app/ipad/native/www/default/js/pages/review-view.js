
/* JavaScript content from js/pages/review-view.js in folder common */

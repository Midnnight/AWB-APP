
/* JavaScript content from js/pages/document-preview-view.js in folder common */
$(".left .back").text("Back");

$(".current-title").text ("Documents Viewer");

/* JavaScript content from js/pages/menus/drawer-menu.js in folder common */


/* JavaScript content from js/pages/employee-profile-view.js in folder common */
$("").text ("Employee profile");
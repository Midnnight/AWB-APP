
/* JavaScript content from js/pages/menus/bottom-menu.js in folder common */

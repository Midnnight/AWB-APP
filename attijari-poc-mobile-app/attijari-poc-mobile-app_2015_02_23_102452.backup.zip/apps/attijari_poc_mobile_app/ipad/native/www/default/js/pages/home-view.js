
/* JavaScript content from js/pages/home-view.js in folder common */

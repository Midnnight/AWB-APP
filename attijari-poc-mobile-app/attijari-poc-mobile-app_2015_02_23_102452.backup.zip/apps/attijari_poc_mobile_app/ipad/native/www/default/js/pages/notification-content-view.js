
/* JavaScript content from js/pages/notification-content-view.js in folder common */
$("#header").css ("display", "none");
$("#footer").css ("display", "none");

$("#loginAction").on ("click", function () {
	loadPage ("pages/login-view.html");
});

/* JavaScript content from js/pages/splash-view.js in folder common */
$("#header").css ("display", "none");
$("#footer").css ("display", "none");

$("#loginAction").on ("click", function () {
	loadPage ("pages/login-view.html");
});

/* JavaScript content from js/pages/supporting-docs-view.js in folder common */

$("#loginAction").on ("click", function () {
	loadPage ("next-best-offer-view.html");
});
$(document).on ("pageshow", function () {
	
	
	
});

$("#register").on('click',function(){
	
	 loadPage("pages/login-view.html");
	
});
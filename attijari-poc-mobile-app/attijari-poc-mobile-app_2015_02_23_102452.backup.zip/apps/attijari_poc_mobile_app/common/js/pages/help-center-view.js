$(".go-to-faq").on ("click", function () {
		loadPage ("faqs-view.html");
	});
	
	$(".go-to-send-problem").on ("click", function () {
		loadPage ("submit-problem-view.html");
	});